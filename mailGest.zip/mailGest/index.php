<?php

//    step 1 : configure the file "mailGestParameter.php" in Parameter folder.
//    step 2 : create your mail template from the model "exemple.php" in mailTemplate Folder

//    step 3 : include de MailGest.php class.

    require('MailGest.php');

//    step 4 : send easily your first email.

    $mail  = new MailGest;
    $mail -> sendTemplate('poelaertch@gmail.com', 'exemple');

?>