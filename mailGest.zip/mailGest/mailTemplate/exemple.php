<?php

// thank you to always keep that structure for your template otherwise it will not work


$mailerName = "Exemple / Newsletter"; // Enter for exemple your name or company name

$sujet = "My first newsletter with mailGest";  // Subjet mail for this template

// Content of your mail
$messageHtml ='Here is the content of your message. you <b>can</b> use html <p> :-) :-) </p>';
