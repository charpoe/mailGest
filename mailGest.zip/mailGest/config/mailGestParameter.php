<?php 



        $mail->CharSet = 'UTF-8';
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'send.one.com';                         // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'hello@squaremob.be';               // SMTP username
        $mailRewrite = 'hello@squaremob.be';                  // rewrite SMTP username
        $mail->Password = 'Peterman<3';                       // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl`
        $mail->Port = 465 ;                                   // TCP port to connect to