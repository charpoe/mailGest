<?php



class MailGest

{  

    public function sendTemplate($toMail, $templates)
    {

        require('mailTemplate/'.$templates.'.php');

        $this -> sendEMail($sujet, $messageHtml, $toMail, $mailerName);
    }

    private function sendEMail($sujet, $message, $toSend, $mailerName){

        require('phpmailer/PHPMailerAutoload.php');

        $mail = new PHPMailer;

        require('config/mailGestParameter.php');

        $mail->setFrom($mailRewrite, $mailerName);
        $mail->addAddress($toSend);


        // Optional name
        $mail->isHTML(true);

        $mail->Subject = $sujet;
        $mail->Body    = $message;

        if(!$mail->send()) {
            echo 'Erreur fatal';
        }
    }
}

?>

